$(document).ready(
    function()
    {
        $('div#exampleTabs').tabs({
            active : 1
        });
    }
);
