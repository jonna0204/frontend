$(document).ready(
    function()
    {
        $('div#exampleTabs').tabs({
            active : 1,
            show : 'explode',
            hide : 'fade'
        });
    }
);
