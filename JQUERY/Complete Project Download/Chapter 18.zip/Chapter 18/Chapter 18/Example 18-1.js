$(document).ready(
    function()
    {
        $('div#exampleTabs').tabs();
    }
);
