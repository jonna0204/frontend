$(document).ready(
    function()
    {
        $('ul').accordion({
            collapsible : true,
            active : false
        });
    }
);
