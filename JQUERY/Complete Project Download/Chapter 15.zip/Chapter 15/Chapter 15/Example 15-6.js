$(document).ready(
    function()
    {
        $('ul').accordion({
            active : 1,
            event : 'mouseover',
            heightStyle : "content",
            header : 'h4'
        });
    }
);
