$(document).ready(
    function()
    {
        $('ul').accordion({
            active : 1
        });
    }
);
