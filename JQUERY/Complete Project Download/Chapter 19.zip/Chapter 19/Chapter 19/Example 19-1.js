$(document).ready(
    function()
    {
        $('table').tablesorter({
            sortList : [
                [2, 0],
                [1, 0]
            ]
        });
    }
);
