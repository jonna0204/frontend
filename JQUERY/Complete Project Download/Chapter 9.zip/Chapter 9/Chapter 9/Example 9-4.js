$.fn.extend({

    contextMenu : function()
    {
        var options = arguments[0] !== undefined ? arguments[0] : {};

        var contextMenuIsEnabled = true;

        var contextMenu = this;

        if (typeof options == 'string')
        {
            switch (options)
            {
                case 'disable':
                {
                    contextMenuIsEnabled = false;
                    break;
                }
            }
        }
        else if (typeof options == 'object')
        {
            // You can pass in an object containing options to
            // further customize your context menu.

        }

        function getViewportDimensions()
        {
            var x, y;

            if (self.innerHeight)
            {
                x = self.innerWidth;
                y = self.innerHeight;
            }
            else if (document.documentElement && document.documentElement.clientHeight)
            {
                x = document.documentElement.clientWidth;
                y = document.documentElement.clientHeight;
            }
            else if (document.body)
            {
                x = document.body.clientWidth;
                y = document.body.clientHeight;
            }

            return {
                x : x,
                y : y
            };
        }

        if (contextMenuIsEnabled)
        {
            // If this is attaching a context menu to multiple elements,
            // iterate over each of them.
            this.find('li')
                .not('li.contextMenuDisabled, li.contextMenuSeparator')
                .bind(
                    'mouseover.contextMenu',
                    function()
                    {
                        $(this).addClass('contextMenuHover');
                    }
                )
                .bind(
                    'mouseout.contextMenu',
                    function()
                    {
                        $(this).removeClass('contextMenuHover');
                    }
                );

            if (!this.data('contextMenu'))
            {
                this.data('contextMenu', true)
                    .addClass('contextMenu')
                    .bind(
                        'mouseover.contextMenu',
                        function()
                        {
                            $(this).data('contextMenu', true);
                        }
                    )
                    .bind(
                        'mouseout.contextMenu',
                        function()
                        {
                            $(this).data('contextMenu', false);
                        }
                    );

                this.parents('.contextMenuContainer:first')
                    .bind(
                        'contextmenu.contextMenu',
                        function(event)
                        {
                            event.preventDefault();

                            var viewport = getViewportDimensions();

                            contextMenu.show();

                            contextMenu.css({
                                top : 'auto',
                                right : 'auto',
                                bottom : 'auto',
                                left : 'auto'
                            });

                            if (contextMenu.outerHeight() > (viewport.y - event.pageY))
                            {
                                contextMenu.css(
                                    'bottom',
                                    (viewport.y - event.pageY) + 'px'
                                );
                            }
                            else
                            {
                                contextMenu.css(
                                    'top',
                                    event.pageY + 'px'
                                );
                            }

                            if (contextMenu.outerWidth() > (viewport.x - event.pageX))
                            {
                                contextMenu.css(
                                    'right',
                                    (viewport.x - event.pageX) + 'px'
                                );
                            }
                            else
                            {
                                contextMenu.css(
                                    'left',
                                    event.pageX + 'px'
                                );
                            }
                        }
                    );
            }

            if (!$('body').data('contextMenu'))
            {
                $('body').data('contextMenu', true);

                $(document).bind(
                    'mousedown.contextMenu',
                    function()
                    {
                        $('div.contextMenu').each(
                            function()
                            {
                                if (!$(this).data('contextMenu'))
                                {
                                    $(this).hide();
                                }
                            }
                        );
                    }
                );
            }
        }
        else
        {
            this.find('li')
                .not('li.contextMenuDisabled, li.contextMenuSeparator')
                .unbind('mouseover.contextMenu')
                .unbind('mouseout.contextMenu');

            this.data('contextMenu', false)
                .removeClass('contextMenu')
                .unbind('mouseover.contextMenu')
                .unbind('mouseout.contextMenu');

            this.parents('.contextMenuContainer:first')
                .unbind('contextmenu.contextMenu');

            $('body').data('contextMenu', false);

            $(document).unbind('mousedown.contextMenu');
        }

        return this;
    }
});

$(document).ready(
    function()
    {
        $('span#applicationContextMenuDisable').click(
            function(event)
            {
                $('div#applicationContextMenu').contextMenu('disable');
                $('div#applicationContextMenu').hide();
            }
        );

        $('span#applicationContextMenuEnable').click(
            function()
            {
                $('div#applicationContextMenu').contextMenu();
            }
        );

        $('div#applicationContextMenu').contextMenu();
    }
);
