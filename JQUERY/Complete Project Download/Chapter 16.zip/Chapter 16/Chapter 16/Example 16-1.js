$(document).ready(
    function()
    {
        $('input#exampleDate').datepicker();
    }
);
