$(document).ready(
    function()
    {
        $('div#exampleDialog').dialog({
            title : "Example Dialog"
        });
    }
);
