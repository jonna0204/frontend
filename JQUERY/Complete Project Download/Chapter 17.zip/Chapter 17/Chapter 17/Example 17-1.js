$(document).ready(
    function()
    {
        $('div#exampleDialog').dialog();
    }
);
