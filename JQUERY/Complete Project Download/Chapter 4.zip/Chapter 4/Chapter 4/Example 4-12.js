$(document).ready(
    function()
    {        
        $('p').unwrap();
    }
);
