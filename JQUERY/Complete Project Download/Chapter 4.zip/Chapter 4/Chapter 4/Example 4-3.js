$(document).ready(
    function()
    {        
        console.log('HTML: ' + $('p').html());
        console.log('Text: ' + $('p').text());
    }
);
