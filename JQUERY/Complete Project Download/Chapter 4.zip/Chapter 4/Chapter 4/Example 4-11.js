$(document).ready(
    function()
    {        
        $('p').wrapInner('<span/>');
    }
);
