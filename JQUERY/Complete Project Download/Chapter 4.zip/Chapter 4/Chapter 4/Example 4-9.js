$(document).ready(
    function()
    {        
        $('p').wrap('<div/>');
    }
);
