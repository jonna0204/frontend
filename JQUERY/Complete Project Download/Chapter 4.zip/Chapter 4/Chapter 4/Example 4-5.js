$(document).ready(
    function()
    {        
        $('p').html(
            'Quote me as saying I was mis-quoted. ' + 
            '<i>- Groucho Marx</i>'
        );
    }
);
