$(document).ready(
    function()
    {        
        $('p').wrapAll('<div/>');
    }
);
