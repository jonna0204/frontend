$(document).ready(
    function()
    {        
        $('p#grouchoQuote1').text(
            'Getting older is no problem. You just have to ' + 
            'live long enough. <i>- Groucho Marx</i>'
        );

        $('p#grouchoQuote2').html(
            'I have had a perfectly wonderful evening, but ' + 
            'this wasn&rsquo;t it. <i>- Groucho Marx</i>'
        );
    }
);
